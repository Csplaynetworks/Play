let contacts = JSON.parse(localStorage.getItem('contacts')) || [];
let currentContactIndex = null;
let mediaRecorder;
let recordedChunks = [];

const contactsContainer = document.getElementById('contacts');
const chatHeader = document.getElementById('chatHeader');
const chatMessages = document.getElementById('chatMessages');
const messageInput = document.getElementById('messageInput');
const sendMessageBtn = document.getElementById('sendMessageBtn');
const replyMessageBtn = document.getElementById('replyMessageBtn');
const addContactBtn = document.getElementById('addContactBtn');
const addContactModal = document.getElementById('addContactModal');
const closeModal = document.getElementById('closeModal');
const saveContactBtn = document.getElementById('saveContactBtn');
const contactNameInput = document.getElementById('contactNameInput');
const contactMobileInput = document.getElementById('contactMobileInput');
const contactPicInput = document.getElementById('contactPicInput');
const contactDescriptionInput = document.getElementById('contactDescriptionInput');
const editContactBtn = document.getElementById('editContactBtn');
const deleteContactBtn = document.getElementById('deleteContactBtn');
const clearChatBtn = document.getElementById('clearChatBtn');
const uploadFilesBtn = document.getElementById('uploadFilesBtn');
const fileInput = document.getElementById('fileInput');
const recordAudioBtn = document.getElementById('recordAudioBtn');
const videoCallBtn = document.getElementById('videoCallBtn');
const callBtn = document.getElementById('callBtn');

function renderContacts() {
    contactsContainer.innerHTML = '';
    contacts.forEach((contact, index) => {
        const contactElement = document.createElement('div');
        contactElement.className = 'contact';
        contactElement.innerHTML = `
            <img src="${contact.pic}" alt="${contact.name}">
            <h4>${contact.name}</h4>
            <p class="last-message">${contact.messages && contact.messages.length ? contact.messages[contact.messages.length - 1] : 'No messages'}</p>
        `;
        contactElement.addEventListener('click', () => openChat(index));
        contactsContainer.appendChild(contactElement);
    });
}

function openChat(index) {
    currentContactIndex = index;
    const contact = contacts[index];
    document.getElementById('contactPic').src = contact.pic;
    document.getElementById('contactName').innerText = contact.name;
    document.getElementById('contactDescription').innerText = contact.description;
    chatMessages.innerHTML = '';
    contact.messages.forEach(message => {
        const messageElement = document.createElement('div');
        messageElement.className = message.startsWith('Reply:') ? 'message reply-message' : 'message sent-message';
        const messageContent = message.startsWith('Image:') || message.startsWith('PDF:') || message.startsWith('Audio:') ?
            `<a href="${message}" target="_blank">View ${message.split(':')[0]}</a>` :
            message;
        messageElement.innerHTML = messageContent;
        chatMessages.appendChild(messageElement);
    });
}

function sendMessage(message) {
    if (message && currentContactIndex !== null) {
        const contact = contacts[currentContactIndex];
        if (!contact.messages) contact.messages = [];
        contact.messages.push(message);
        openChat(currentContactIndex);
        localStorage.setItem('contacts', JSON.stringify(contacts));
        renderContacts(); // Update last message
    }
}

sendMessageBtn.addEventListener('click', () => {
    const message = messageInput.value;
    sendMessage(message);
    messageInput.value = '';
});

replyMessageBtn.addEventListener('click', () => {
    const replyMessage = prompt("Enter reply message:");
    sendMessage("Reply: " + replyMessage);
});

uploadFilesBtn.addEventListener('click', () => {
    fileInput.click();
});

fileInput.addEventListener('change', () => {
    const files = fileInput.files;
    if (files.length && files.length <= 2 && currentContactIndex !== null) {
        const contact = contacts[currentContactIndex];
        if (!contact.messages) contact.messages = [];
        for (const file of files) {
            if (file) {
                const reader = new FileReader();
                reader.onload = function() {
                    const fileDataURL = reader.result;
                    const messageType = file.type.includes('pdf') ? 'PDF' : 'Image';
                    sendMessage(`${messageType}: ${fileDataURL}`);
                };
                reader.readAsDataURL(file);
            }
        }
        fileInput.value = ''; // Clear file input
    } else if (files.length > 2) {
        alert("You can only select up to 2 files.");
    }
});

recordAudioBtn.addEventListener('click', async () => {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert("Media devices not supported.");
        return;
    }
    try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        mediaRecorder = new MediaRecorder(stream);
        mediaRecorder.ondataavailable = function(event) {
            if (event.data.size > 0) {
                recordedChunks.push(event.data);
            }
        };
        mediaRecorder.onstop = function() {
            const audioBlob = new Blob(recordedChunks, { type: 'audio/webm' });
            const audioURL = URL.createObjectURL(audioBlob);
            sendMessage(`Audio: ${audioURL}`);
        };
        mediaRecorder.start();
        recordAudioBtn.innerHTML = '<i class="fas fa-stop"></i>';
        recordAudioBtn.addEventListener('click', () => {
            mediaRecorder.stop();
            recordAudioBtn.innerHTML = '<i class="fas fa-microphone"></i>';
        }, { once: true });
    } catch (error) {
        alert("Error accessing audio devices.");
    }
});

videoCallBtn.addEventListener('click', () => {
    alert("Video call feature not implemented.");
});

callBtn.addEventListener('click', () => {
    alert("Voice call feature not implemented.");
});

addContactBtn.addEventListener('click', () => {
    document.getElementById('modalTitle').innerText = 'Add New Contact';
    saveContactBtn.innerText = 'Save Contact';
    contactNameInput.value = '';
    contactMobileInput.value = '';
    contactPicInput.value = '';
    contactDescriptionInput.value = '';
    currentContactIndex = null;
    addContactModal.style.display = 'block';
});

closeModal.addEventListener('click', () => {
    addContactModal.style.display = 'none';
});

saveContactBtn.addEventListener('click', () => {
    const reader = new FileReader();
    reader.onload = function() {
        const picDataURL = reader.result;
        const newContact = {
            name: contactNameInput.value,
            mobile: contactMobileInput.value,
            pic: picDataURL,
            description: contactDescriptionInput.value,
            messages: []
        };
        if (currentContactIndex !== null) {
            contacts[currentContactIndex] = newContact;
        } else {
            contacts.push(newContact);
        }
        localStorage.setItem('contacts', JSON.stringify(contacts));
        renderContacts();
        addContactModal.style.display = 'none';
    };
    reader.readAsDataURL(contactPicInput.files[0]);
});

editContactBtn.addEventListener('click', () => {
    if (currentContactIndex !== null) {
        document.getElementById('modalTitle').innerText = 'Edit Contact';
        saveContactBtn.innerText = 'Update Contact';
        const contact = contacts[currentContactIndex];
        contactNameInput.value = contact.name;
        contactMobileInput.value = contact.mobile;
        contactDescriptionInput.value = contact.description;
        addContactModal.style.display = 'block';
    }
});

deleteContactBtn.addEventListener('click', () => {
    if (currentContactIndex !== null) {
        contacts.splice(currentContactIndex, 1);
        localStorage.setItem('contacts', JSON.stringify(contacts));
        renderContacts();
        chatMessages.innerHTML = '';
        document.getElementById('contactPic').src = '';
        document.getElementById('contactName').innerText = 'Contact Name';
        document.getElementById('contactDescription').innerText = 'Contact Description';
        currentContactIndex = null;
    }
});

clearChatBtn.addEventListener('click', () => {
    if (currentContactIndex !== null) {
        contacts[currentContactIndex].messages = [];
        localStorage.setItem('contacts', JSON.stringify(contacts));
        openChat(currentContactIndex);
    }
});

renderContacts();
